#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private DMFXCOTCmdtsFutNetPositions[] cacheDMFXCOTCmdtsFutNetPositions;
		private DMFXCOTCmdtsFutOptNetPositions[] cacheDMFXCOTCmdtsFutOptNetPositions;
		private DMFXCOTFinFutNetPositions[] cacheDMFXCOTFinFutNetPositions;
		private DMFXCOTFinFutOptNetPositions[] cacheDMFXCOTFinFutOptNetPositions;

		
		public DMFXCOTCmdtsFutNetPositions DMFXCOTCmdtsFutNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return DMFXCOTCmdtsFutNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public DMFXCOTCmdtsFutOptNetPositions DMFXCOTCmdtsFutOptNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutOptNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return DMFXCOTCmdtsFutOptNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public DMFXCOTFinFutNetPositions DMFXCOTFinFutNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return DMFXCOTFinFutNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public DMFXCOTFinFutOptNetPositions DMFXCOTFinFutOptNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutOptNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return DMFXCOTFinFutOptNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}


		
		public DMFXCOTCmdtsFutNetPositions DMFXCOTCmdtsFutNetPositions(ISeries<double> input, string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			if (cacheDMFXCOTCmdtsFutNetPositions != null)
				for (int idx = 0; idx < cacheDMFXCOTCmdtsFutNetPositions.Length; idx++)
					if (cacheDMFXCOTCmdtsFutNetPositions[idx].AccountKey == accountKey && cacheDMFXCOTCmdtsFutNetPositions[idx].COTCode == cOTCode && cacheDMFXCOTCmdtsFutNetPositions[idx].WeeksBack == weeksBack && cacheDMFXCOTCmdtsFutNetPositions[idx].Host == host && cacheDMFXCOTCmdtsFutNetPositions[idx].EqualsInput(input))
						return cacheDMFXCOTCmdtsFutNetPositions[idx];
			return CacheIndicator<DMFXCOTCmdtsFutNetPositions>(new DMFXCOTCmdtsFutNetPositions(){ AccountKey = accountKey, COTCode = cOTCode, WeeksBack = weeksBack, Host = host }, input, ref cacheDMFXCOTCmdtsFutNetPositions);
		}

		public DMFXCOTCmdtsFutOptNetPositions DMFXCOTCmdtsFutOptNetPositions(ISeries<double> input, string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutOptNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			if (cacheDMFXCOTCmdtsFutOptNetPositions != null)
				for (int idx = 0; idx < cacheDMFXCOTCmdtsFutOptNetPositions.Length; idx++)
					if (cacheDMFXCOTCmdtsFutOptNetPositions[idx].AccountKey == accountKey && cacheDMFXCOTCmdtsFutOptNetPositions[idx].COTCode == cOTCode && cacheDMFXCOTCmdtsFutOptNetPositions[idx].WeeksBack == weeksBack && cacheDMFXCOTCmdtsFutOptNetPositions[idx].Host == host && cacheDMFXCOTCmdtsFutOptNetPositions[idx].EqualsInput(input))
						return cacheDMFXCOTCmdtsFutOptNetPositions[idx];
			return CacheIndicator<DMFXCOTCmdtsFutOptNetPositions>(new DMFXCOTCmdtsFutOptNetPositions(){ AccountKey = accountKey, COTCode = cOTCode, WeeksBack = weeksBack, Host = host }, input, ref cacheDMFXCOTCmdtsFutOptNetPositions);
		}

		public DMFXCOTFinFutNetPositions DMFXCOTFinFutNetPositions(ISeries<double> input, string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			if (cacheDMFXCOTFinFutNetPositions != null)
				for (int idx = 0; idx < cacheDMFXCOTFinFutNetPositions.Length; idx++)
					if (cacheDMFXCOTFinFutNetPositions[idx].AccountKey == accountKey && cacheDMFXCOTFinFutNetPositions[idx].COTCode == cOTCode && cacheDMFXCOTFinFutNetPositions[idx].WeeksBack == weeksBack && cacheDMFXCOTFinFutNetPositions[idx].Host == host && cacheDMFXCOTFinFutNetPositions[idx].EqualsInput(input))
						return cacheDMFXCOTFinFutNetPositions[idx];
			return CacheIndicator<DMFXCOTFinFutNetPositions>(new DMFXCOTFinFutNetPositions(){ AccountKey = accountKey, COTCode = cOTCode, WeeksBack = weeksBack, Host = host }, input, ref cacheDMFXCOTFinFutNetPositions);
		}

		public DMFXCOTFinFutOptNetPositions DMFXCOTFinFutOptNetPositions(ISeries<double> input, string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutOptNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			if (cacheDMFXCOTFinFutOptNetPositions != null)
				for (int idx = 0; idx < cacheDMFXCOTFinFutOptNetPositions.Length; idx++)
					if (cacheDMFXCOTFinFutOptNetPositions[idx].AccountKey == accountKey && cacheDMFXCOTFinFutOptNetPositions[idx].COTCode == cOTCode && cacheDMFXCOTFinFutOptNetPositions[idx].WeeksBack == weeksBack && cacheDMFXCOTFinFutOptNetPositions[idx].Host == host && cacheDMFXCOTFinFutOptNetPositions[idx].EqualsInput(input))
						return cacheDMFXCOTFinFutOptNetPositions[idx];
			return CacheIndicator<DMFXCOTFinFutOptNetPositions>(new DMFXCOTFinFutOptNetPositions(){ AccountKey = accountKey, COTCode = cOTCode, WeeksBack = weeksBack, Host = host }, input, ref cacheDMFXCOTFinFutOptNetPositions);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.DMFXCOTCmdtsFutNetPositions DMFXCOTCmdtsFutNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTCmdtsFutNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTCmdtsFutOptNetPositions DMFXCOTCmdtsFutOptNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutOptNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTCmdtsFutOptNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTFinFutNetPositions DMFXCOTFinFutNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTFinFutNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTFinFutOptNetPositions DMFXCOTFinFutOptNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutOptNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTFinFutOptNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}


		
		public Indicators.DMFXCOTCmdtsFutNetPositions DMFXCOTCmdtsFutNetPositions(ISeries<double> input , string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTCmdtsFutNetPositions(input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTCmdtsFutOptNetPositions DMFXCOTCmdtsFutOptNetPositions(ISeries<double> input , string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutOptNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTCmdtsFutOptNetPositions(input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTFinFutNetPositions DMFXCOTFinFutNetPositions(ISeries<double> input , string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTFinFutNetPositions(input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTFinFutOptNetPositions DMFXCOTFinFutOptNetPositions(ISeries<double> input , string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutOptNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTFinFutOptNetPositions(input, accountKey, cOTCode, weeksBack, host);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.DMFXCOTCmdtsFutNetPositions DMFXCOTCmdtsFutNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTCmdtsFutNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTCmdtsFutOptNetPositions DMFXCOTCmdtsFutOptNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutOptNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTCmdtsFutOptNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTFinFutNetPositions DMFXCOTFinFutNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTFinFutNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTFinFutOptNetPositions DMFXCOTFinFutOptNetPositions(string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutOptNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTFinFutOptNetPositions(Input, accountKey, cOTCode, weeksBack, host);
		}


		
		public Indicators.DMFXCOTCmdtsFutNetPositions DMFXCOTCmdtsFutNetPositions(ISeries<double> input , string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTCmdtsFutNetPositions(input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTCmdtsFutOptNetPositions DMFXCOTCmdtsFutOptNetPositions(ISeries<double> input , string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTCmdtsFutOptNetPositions.ECOTCmdtsCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTCmdtsFutOptNetPositions(input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTFinFutNetPositions DMFXCOTFinFutNetPositions(ISeries<double> input , string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTFinFutNetPositions(input, accountKey, cOTCode, weeksBack, host);
		}

		public Indicators.DMFXCOTFinFutOptNetPositions DMFXCOTFinFutOptNetPositions(ISeries<double> input , string accountKey, NinjaTrader.NinjaScript.Indicators.DMFXCOTFinFutOptNetPositions.ECOTFinCodes cOTCode, int weeksBack, string host)
		{
			return indicator.DMFXCOTFinFutOptNetPositions(input, accountKey, cOTCode, weeksBack, host);
		}

	}
}

#endregion
